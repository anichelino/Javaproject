package com.practice.java8.studentManagementSystem;

public interface Enrollable {
    public default void enrollToCourse(Course course){

    }
}
